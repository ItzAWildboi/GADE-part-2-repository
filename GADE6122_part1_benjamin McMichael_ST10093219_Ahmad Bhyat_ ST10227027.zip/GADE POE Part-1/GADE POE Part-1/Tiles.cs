﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GADE_POE_Part_1
{
    public abstract class Tiles
    {
        public int X;
        public int Y;
         public enum TileType
        {
            Hero,
            Enemy,
            Gold,
            Weapon
        }

        public Tiles(int X, int Y)
        {
            this.X = X;
            this.Y = Y;
        }
    }
    public class obstacle : Tiles
    {
        public obstacle(int X, int Y) : base(X, Y)
        {
            X = 15;
            Y = 8;         

        public int X { get; set }
        public int Y { get; set; }
        }
    }

    class EmptyTile : Tiles
    {
        public EmptyTile(int X, int Y) : base(X, Y)
        {
        }
    }
}
