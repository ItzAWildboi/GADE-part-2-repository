﻿namespace GADE_POE_Part_1
{
    partial class Character
    {
        enum Movement
        {
            no movement,
            up,
            down,
            left,
            right,
        }


    }
}
