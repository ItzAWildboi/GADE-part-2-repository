﻿namespace GADE_POE_Part_1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnleft = new System.Windows.Forms.Button();
            this.btnright = new System.Windows.Forms.Button();
            this.btndwn = new System.Windows.Forms.Button();
            this.btnup = new System.Windows.Forms.Button();
            this.lblattk = new System.Windows.Forms.Label();
            this.btnattku = new System.Windows.Forms.Button();
            this.btnattkl = new System.Windows.Forms.Button();
            this.btnattkd = new System.Windows.Forms.Button();
            this.btnattkr = new System.Windows.Forms.Button();
            this.lblattkup = new System.Windows.Forms.Label();
            this.lblattkleft = new System.Windows.Forms.Label();
            this.lblattkright = new System.Windows.Forms.Label();
            this.lblattkdwn = new System.Windows.Forms.Label();
            this.lblmvmntlr = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnleft
            // 
            this.btnleft.Location = new System.Drawing.Point(15, 316);
            this.btnleft.Name = "btnleft";
            this.btnleft.Size = new System.Drawing.Size(114, 40);
            this.btnleft.TabIndex = 0;
            this.btnleft.Text = "left";
            this.btnleft.UseVisualStyleBackColor = true;
            // 
            // btnright
            // 
            this.btnright.Location = new System.Drawing.Point(135, 316);
            this.btnright.Name = "btnright";
            this.btnright.Size = new System.Drawing.Size(114, 40);
            this.btnright.TabIndex = 1;
            this.btnright.Text = "right";
            this.btnright.UseVisualStyleBackColor = true;
            // 
            // btndwn
            // 
            this.btndwn.Location = new System.Drawing.Point(720, 359);
            this.btndwn.Name = "btndwn";
            this.btndwn.Size = new System.Drawing.Size(136, 36);
            this.btndwn.TabIndex = 2;
            this.btndwn.Text = "down";
            this.btndwn.UseVisualStyleBackColor = true;
            // 
            // btnup
            // 
            this.btnup.Location = new System.Drawing.Point(720, 316);
            this.btnup.Name = "btnup";
            this.btnup.Size = new System.Drawing.Size(136, 36);
            this.btnup.TabIndex = 3;
            this.btnup.Text = "up";
            this.btnup.UseVisualStyleBackColor = true;
            // 
            // lblattk
            // 
            this.lblattk.AutoSize = true;
            this.lblattk.Location = new System.Drawing.Point(425, 306);
            this.lblattk.Name = "lblattk";
            this.lblattk.Size = new System.Drawing.Size(79, 15);
            this.lblattk.TabIndex = 4;
            this.lblattk.Text = "attk_direction";
            // 
            // btnattku
            // 
            this.btnattku.Location = new System.Drawing.Point(425, 333);
            this.btnattku.Name = "btnattku";
            this.btnattku.Size = new System.Drawing.Size(75, 23);
            this.btnattku.TabIndex = 5;
            this.btnattku.Text = "attack";
            this.btnattku.UseVisualStyleBackColor = true;
            // 
            // btnattkl
            // 
            this.btnattkl.Location = new System.Drawing.Point(425, 362);
            this.btnattkl.Name = "btnattkl";
            this.btnattkl.Size = new System.Drawing.Size(75, 23);
            this.btnattkl.TabIndex = 6;
            this.btnattkl.Text = "attack";
            this.btnattkl.UseVisualStyleBackColor = true;
            // 
            // btnattkd
            // 
            this.btnattkd.Location = new System.Drawing.Point(425, 420);
            this.btnattkd.Name = "btnattkd";
            this.btnattkd.Size = new System.Drawing.Size(75, 23);
            this.btnattkd.TabIndex = 7;
            this.btnattkd.Text = "attack";
            this.btnattkd.UseVisualStyleBackColor = true;
            // 
            // btnattkr
            // 
            this.btnattkr.Location = new System.Drawing.Point(425, 391);
            this.btnattkr.Name = "btnattkr";
            this.btnattkr.Size = new System.Drawing.Size(75, 23);
            this.btnattkr.TabIndex = 8;
            this.btnattkr.Text = "attack";
            this.btnattkr.UseVisualStyleBackColor = true;
            // 
            // lblattkup
            // 
            this.lblattkup.AutoSize = true;
            this.lblattkup.Location = new System.Drawing.Point(398, 337);
            this.lblattkup.Name = "lblattkup";
            this.lblattkup.Size = new System.Drawing.Size(24, 15);
            this.lblattkup.TabIndex = 9;
            this.lblattkup.Text = "up:";
            // 
            // lblattkleft
            // 
            this.lblattkleft.AutoSize = true;
            this.lblattkleft.Location = new System.Drawing.Point(395, 366);
            this.lblattkleft.Name = "lblattkleft";
            this.lblattkleft.Size = new System.Drawing.Size(27, 15);
            this.lblattkleft.TabIndex = 10;
            this.lblattkleft.Text = "left:";
            // 
            // lblattkright
            // 
            this.lblattkright.AutoSize = true;
            this.lblattkright.Location = new System.Drawing.Point(387, 395);
            this.lblattkright.Name = "lblattkright";
            this.lblattkright.Size = new System.Drawing.Size(35, 15);
            this.lblattkright.TabIndex = 11;
            this.lblattkright.Text = "right:";
            // 
            // lblattkdwn
            // 
            this.lblattkdwn.AutoSize = true;
            this.lblattkdwn.Location = new System.Drawing.Point(382, 424);
            this.lblattkdwn.Name = "lblattkdwn";
            this.lblattkdwn.Size = new System.Drawing.Size(40, 15);
            this.lblattkdwn.TabIndex = 12;
            this.lblattkdwn.Text = "down:";
            // 
            // lblmvmntlr
            // 
            this.lblmvmntlr.AutoSize = true;
            this.lblmvmntlr.Location = new System.Drawing.Point(64, 298);
            this.lblmvmntlr.Name = "lblmvmntlr";
            this.lblmvmntlr.Size = new System.Drawing.Size(136, 15);
            this.lblmvmntlr.TabIndex = 13;
            this.lblmvmntlr.Text = "Movement left and right";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(718, 298);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 15);
            this.label1.TabIndex = 14;
            this.label1.Text = "movement up and down";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(868, 510);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblmvmntlr);
            this.Controls.Add(this.lblattkdwn);
            this.Controls.Add(this.lblattkright);
            this.Controls.Add(this.lblattkleft);
            this.Controls.Add(this.lblattkup);
            this.Controls.Add(this.btnattkr);
            this.Controls.Add(this.btnattkd);
            this.Controls.Add(this.btnattkl);
            this.Controls.Add(this.btnattku);
            this.Controls.Add(this.lblattk);
            this.Controls.Add(this.btnup);
            this.Controls.Add(this.btndwn);
            this.Controls.Add(this.btnright);
            this.Controls.Add(this.btnleft);
            this.Name = "Form1";
            this.Text = "Hero game";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnleft;
        private System.Windows.Forms.Button btnright;
        private System.Windows.Forms.Button btndwn;
        private System.Windows.Forms.Button btnup;
        private System.Windows.Forms.Label lblattk;
        private System.Windows.Forms.Button btnattku;
        private System.Windows.Forms.Button btnattkl;
        private System.Windows.Forms.Button btnattkd;
        private System.Windows.Forms.Button btnattkr;
        private System.Windows.Forms.Label lblattkup;
        private System.Windows.Forms.Label lblattkleft;
        private System.Windows.Forms.Label lblattkright;
        private System.Windows.Forms.Label lblattkdwn;
        private System.Windows.Forms.Label lblmvmntlr;
        private System.Windows.Forms.Label label1;
    }
}
