﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GADE_POE_Part_1
{
     class Character : Tiles 
     {
       protected int HP;
       protected int maxHP;
       protected int Damage;
       string[] vision = { "North", "South", "East", "West" };
        enum Movement
        {
            noMovement,
            up,
            down,
            left,
            right,
        }

        public Tile[] CharacterVision { get; set; } = new Tile[];


     }
}
