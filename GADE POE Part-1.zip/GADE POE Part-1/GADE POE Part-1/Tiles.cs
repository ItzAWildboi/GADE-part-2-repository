﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GADE_POE_Part_1
{
    public abstract class Tiles
    {
        public int X;
        public int Y;
        public enum TileType
        {
            Hero = 'H',
            Enemy = 'E',
            Gold = '$',
            Weapon = 'W',
            Obstacle = 'X',
            EmptyTile = '_'
        }

         class obstacle
        {

        }

         class emptyTile
        {

        }


    }
}
