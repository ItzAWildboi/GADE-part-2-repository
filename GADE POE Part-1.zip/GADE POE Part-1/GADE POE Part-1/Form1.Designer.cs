﻿namespace GADE_POE_Part_1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnleft = new System.Windows.Forms.Button();
            this.btnright = new System.Windows.Forms.Button();
            this.btndwn = new System.Windows.Forms.Button();
            this.btnup = new System.Windows.Forms.Button();
            this.lblattk = new System.Windows.Forms.Label();
            this.btnattku = new System.Windows.Forms.Button();
            this.btnattkl = new System.Windows.Forms.Button();
            this.btnattkd = new System.Windows.Forms.Button();
            this.btnattkr = new System.Windows.Forms.Button();
            this.lblattkup = new System.Windows.Forms.Label();
            this.lblattkleft = new System.Windows.Forms.Label();
            this.lblattkright = new System.Windows.Forms.Label();
            this.lblattkdwn = new System.Windows.Forms.Label();
            this.lblmvmntlr = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnleft
            // 
            this.btnleft.Location = new System.Drawing.Point(17, 421);
            this.btnleft.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnleft.Name = "btnleft";
            this.btnleft.Size = new System.Drawing.Size(130, 53);
            this.btnleft.TabIndex = 0;
            this.btnleft.Text = "left";
            this.btnleft.UseVisualStyleBackColor = true;
            // 
            // btnright
            // 
            this.btnright.Location = new System.Drawing.Point(154, 421);
            this.btnright.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnright.Name = "btnright";
            this.btnright.Size = new System.Drawing.Size(130, 53);
            this.btnright.TabIndex = 1;
            this.btnright.Text = "right";
            this.btnright.UseVisualStyleBackColor = true;
            // 
            // btndwn
            // 
            this.btndwn.Location = new System.Drawing.Point(823, 479);
            this.btndwn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btndwn.Name = "btndwn";
            this.btndwn.Size = new System.Drawing.Size(155, 48);
            this.btndwn.TabIndex = 2;
            this.btndwn.Text = "down";
            this.btndwn.UseVisualStyleBackColor = true;
            // 
            // btnup
            // 
            this.btnup.Location = new System.Drawing.Point(823, 421);
            this.btnup.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnup.Name = "btnup";
            this.btnup.Size = new System.Drawing.Size(155, 48);
            this.btnup.TabIndex = 3;
            this.btnup.Text = "up";
            this.btnup.UseVisualStyleBackColor = true;
            // 
            // lblattk
            // 
            this.lblattk.AutoSize = true;
            this.lblattk.Location = new System.Drawing.Point(486, 408);
            this.lblattk.Name = "lblattk";
            this.lblattk.Size = new System.Drawing.Size(99, 20);
            this.lblattk.TabIndex = 4;
            this.lblattk.Text = "attk_direction";
            // 
            // btnattku
            // 
            this.btnattku.Location = new System.Drawing.Point(486, 444);
            this.btnattku.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnattku.Name = "btnattku";
            this.btnattku.Size = new System.Drawing.Size(86, 31);
            this.btnattku.TabIndex = 5;
            this.btnattku.Text = "attack";
            this.btnattku.UseVisualStyleBackColor = true;
            // 
            // btnattkl
            // 
            this.btnattkl.Location = new System.Drawing.Point(486, 483);
            this.btnattkl.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnattkl.Name = "btnattkl";
            this.btnattkl.Size = new System.Drawing.Size(86, 31);
            this.btnattkl.TabIndex = 6;
            this.btnattkl.Text = "attack";
            this.btnattkl.UseVisualStyleBackColor = true;
            // 
            // btnattkd
            // 
            this.btnattkd.Location = new System.Drawing.Point(486, 560);
            this.btnattkd.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnattkd.Name = "btnattkd";
            this.btnattkd.Size = new System.Drawing.Size(86, 31);
            this.btnattkd.TabIndex = 7;
            this.btnattkd.Text = "attack";
            this.btnattkd.UseVisualStyleBackColor = true;
            // 
            // btnattkr
            // 
            this.btnattkr.Location = new System.Drawing.Point(486, 521);
            this.btnattkr.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnattkr.Name = "btnattkr";
            this.btnattkr.Size = new System.Drawing.Size(86, 31);
            this.btnattkr.TabIndex = 8;
            this.btnattkr.Text = "attack";
            this.btnattkr.UseVisualStyleBackColor = true;
            // 
            // lblattkup
            // 
            this.lblattkup.AutoSize = true;
            this.lblattkup.Location = new System.Drawing.Point(455, 449);
            this.lblattkup.Name = "lblattkup";
            this.lblattkup.Size = new System.Drawing.Size(29, 20);
            this.lblattkup.TabIndex = 9;
            this.lblattkup.Text = "up:";
            // 
            // lblattkleft
            // 
            this.lblattkleft.AutoSize = true;
            this.lblattkleft.Location = new System.Drawing.Point(451, 488);
            this.lblattkleft.Name = "lblattkleft";
            this.lblattkleft.Size = new System.Drawing.Size(34, 20);
            this.lblattkleft.TabIndex = 10;
            this.lblattkleft.Text = "left:";
            // 
            // lblattkright
            // 
            this.lblattkright.AutoSize = true;
            this.lblattkright.Location = new System.Drawing.Point(442, 527);
            this.lblattkright.Name = "lblattkright";
            this.lblattkright.Size = new System.Drawing.Size(43, 20);
            this.lblattkright.TabIndex = 11;
            this.lblattkright.Text = "right:";
            // 
            // lblattkdwn
            // 
            this.lblattkdwn.AutoSize = true;
            this.lblattkdwn.Location = new System.Drawing.Point(437, 565);
            this.lblattkdwn.Name = "lblattkdwn";
            this.lblattkdwn.Size = new System.Drawing.Size(49, 20);
            this.lblattkdwn.TabIndex = 12;
            this.lblattkdwn.Text = "down:";
            // 
            // lblmvmntlr
            // 
            this.lblmvmntlr.AutoSize = true;
            this.lblmvmntlr.Location = new System.Drawing.Point(73, 397);
            this.lblmvmntlr.Name = "lblmvmntlr";
            this.lblmvmntlr.Size = new System.Drawing.Size(170, 20);
            this.lblmvmntlr.TabIndex = 13;
            this.lblmvmntlr.Text = "Movement left and right";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(821, 397);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 20);
            this.label1.TabIndex = 14;
            this.label1.Text = "movement up and down";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(522, 122);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 20);
            this.label2.TabIndex = 15;
            this.label2.Text = "Player stats:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(522, 151);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 20);
            this.label3.TabIndex = 16;
            this.label3.Text = "HP:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(522, 181);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 20);
            this.label4.TabIndex = 17;
            this.label4.Text = "Damage:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(522, 212);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 20);
            this.label5.TabIndex = 18;
            this.label5.Text = "label5";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(992, 680);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblmvmntlr);
            this.Controls.Add(this.lblattkdwn);
            this.Controls.Add(this.lblattkright);
            this.Controls.Add(this.lblattkleft);
            this.Controls.Add(this.lblattkup);
            this.Controls.Add(this.btnattkr);
            this.Controls.Add(this.btnattkd);
            this.Controls.Add(this.btnattkl);
            this.Controls.Add(this.btnattku);
            this.Controls.Add(this.lblattk);
            this.Controls.Add(this.btnup);
            this.Controls.Add(this.btndwn);
            this.Controls.Add(this.btnright);
            this.Controls.Add(this.btnleft);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "Hero game";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnleft;
        private System.Windows.Forms.Button btnright;
        private System.Windows.Forms.Button btndwn;
        private System.Windows.Forms.Button btnup;
        private System.Windows.Forms.Label lblattk;
        private System.Windows.Forms.Button btnattku;
        private System.Windows.Forms.Button btnattkl;
        private System.Windows.Forms.Button btnattkd;
        private System.Windows.Forms.Button btnattkr;
        private System.Windows.Forms.Label lblattkup;
        private System.Windows.Forms.Label lblattkleft;
        private System.Windows.Forms.Label lblattkright;
        private System.Windows.Forms.Label lblattkdwn;
        private System.Windows.Forms.Label lblmvmntlr;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}
