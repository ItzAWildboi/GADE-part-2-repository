﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GADE_POE_Part_1
{
    internal class map
    {
         private int[,] mapGrid = new int[,]
        {
            {1,1,1,1,1,1 } ,
            {1,0,0,0,0,1 },
            {1,0,0,0,0,1 },
            {1,0,0,0,0,1 },
            {1,0,0,0,0,1 },
            {1,0,0,0,0,1 },
            {1,0,0,0,0,1 },
            {1,0,0,0,0,1 },
            {1,0,0,0,0,1 },
            {1,1,1,1,1,1 }
        };
         
    }
    private int[,] Enemy = new int[,]
    {
            {1,1,1,1,1,1 } ,
            {1,0,0,0,2,1 },
            {1,0,0,0,0,1 },
            {1,0,0,2,0,1 },
            {1,0,0,0,0,1 },
            {1,0,2,0,0,1 },
            {1,0,0,0,2,1 },
            {1,0,0,2,0,1 },
            {1,2,0,0,0,1 },
            {1,1,1,1,1,1 }
    };


        

}
